CREATE TABLE dw_job_80_99(
	id bigint,
	name nvarchar(40),
	occ_type nvarchar(100),
	occupation nvarchar(200),
	date_s date ,
	date_e date ,
	reason nvarchar(100) ,
	department1 nvarchar(100) ,
	department2 nvarchar(100) ,
	rank1 nvarchar(40) ,
	rank2 nvarchar(40) ,
	appointment1 nvarchar(100) ,
	appointment2 nvarchar(100) ,
	president nvarchar(40) ,
	premier nvarchar(40) 
)